This folder contains:

1. The actual website code, trivialWeb
2. The packages that go into the package repository (Index_v100.zip, Index_v101.zip)
3. And in the TrivialWeb folder are the NuGet metadata bits.

