﻿$ErrorActionPreference = 'Stop'; # stop on all errors

$packageName = 'trivialweb' # arbitrary name for the package, used in messages
$zipFileName = "trivialwebInstall.zip"

$packageArgs = @{
  packageName   = $packageName
  zipFileName   = $zipFileName
}

Uninstall-ChocolateyZipPackage $packageName $zipFileName
