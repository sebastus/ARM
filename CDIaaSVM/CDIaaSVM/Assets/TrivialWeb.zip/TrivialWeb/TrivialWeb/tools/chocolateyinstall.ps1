﻿$ErrorActionPreference = 'Stop'; # stop on all errors

$packageName = 'trivialweb' # arbitrary name for the package, used in messages
$toolsDir = "c:\inetpub\wwwroot"
$url = 'https://goliveazurewest.blob.core.windows.net/public/index_v102.zip' # download url

$packageArgs = @{
  packageName   = $packageName
  unzipLocation = $toolsDir
  url           = $url
}

Install-ChocolateyZipPackage @packageArgs
