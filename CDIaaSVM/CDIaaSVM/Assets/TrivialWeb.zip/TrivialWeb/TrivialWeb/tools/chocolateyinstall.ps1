﻿#NOTE: Please remove any commented lines to tidy up prior to releasing the package, including this one
# REMOVE ANYTHING BELOW THAT IS NOT NEEDED

$ErrorActionPreference = 'Stop'; # stop on all errors

$packageName = 'TrivialWeb' # arbitrary name for the package, used in messages
$toolsDir = "c:\inetpub\wwwroot"
$url = 'https://goliveazurewest.blob.core.windows.net/public/index_v100.zip' # download url

$packageArgs = @{
  packageName   = $packageName
  unzipLocation = $toolsDir
  url           = $url
}

Install-ChocolateyZipPackage @packageArgs

